package Controller;

import Model.Jogo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.util.Set;

public class JogoDao extends ConectarDao {

    private PreparedStatement ps;

    public JogoDao() {
        super();
    }

    public void incluir(Jogo obj) {
        sql = "INSERT INTO JOGOS VALUES (?, ?, ?, ?, ?, ?)";
        try {
            ps = mycon.prepareStatement(sql);
            ps.setInt(1, obj.getIdJogo());
            ps.setString(2, obj.getNome());
            ps.setString(3, obj.getTg());
            ps.setString(4, obj.getProdutora());
            ps.setString(5, obj.getPlataforma());
            ps.setString(6, obj.getIdadeClassificada());
            ps.execute();
            ps.close();
            JOptionPane.showMessageDialog(null, "Registro Incluído com Sucesso!");
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao incluir jogo!" + err.getMessage());
        }
    }
    
    public void alterar (Jogo obj) {
          sql = "UPDATE JOGOS SET nome = ?, tipo_genero = ?, produtora = ?, plataforma = ?, idade_indicativa = ? WHERE idJogo = ?";
          try {
            ps = mycon.prepareStatement(sql);
            ps.setString(1, obj.getNome());
            ps.setString(2, obj.getTg());
            ps.setString(3, obj.getProdutora());
            ps.setString(4, obj.getPlataforma());
            ps.setString(5, obj.getIdadeClassificada());
            ps.setInt(6, obj.getIdJogo());

            ps.execute();
            ps.close();
            JOptionPane.showMessageDialog(null, "Registro Incluído com Sucesso!");
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar jogo!" + err.getMessage());
        }
    }

    public ResultSet buscartodos() {
        sql = "SELECT * FROM JOGOS ORDER BY idJogo ";
        try {
            ps = mycon.prepareStatement(sql);
            return ps.executeQuery();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao Buscar jogo!"
                    + err.getMessage());
            return null;
        }
    }

    public ResultSet buscar(Jogo obj) {
// para buscar um registro especifico cria-se um sql com um parãmetro chave
// no caso a busca está sendo feita pelo cpf do usuario
        sql = "SELECT * FROM JOGOS WHERE idJogo = ?";
        try { // liga o sql com a conexão atraveś do objeto ps
            ps = mycon.prepareStatement(sql);
// configura o único parametro existente
            ps.setInt(1, obj.getIdJogo());
// retorna o registro selecionado
            return ps.executeQuery();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao Buscar jogo!"
                    + err.getMessage());
            return null;
        }
    }

    public void excluir(String idJogo) {
// configura o comando sql de exclusão delete por cpf
        sql = "DELETE FROM JOGOS WHERE idJogo = '" + idJogo + "'";
        try { // envia o comando sql para dentro da conexão através deps 
            ps = mycon.prepareStatement(sql);
// executa o comando delete dentro do mysql
            ps.execute();
            ps.close(); // fecha o objeto usado para executar o comando sql
            JOptionPane.showMessageDialog(null,"Registro Excluido com Sucesso"
                    + "!");
} catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao Excluir emprestimo!"
                    + err.getMessage());
        }
    }

}
