package Controller;

import Model.Emprestimo;

import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class EmprestimoDao extends ConectarDao {

    private PreparedStatement ps;

    public EmprestimoDao() {
        super();
    }

    public void incluir ( Emprestimo obj ) {
        sql = "INSERT INTO EMPRESTIMOS VALUES (?, ?, ?)";
        try {
            ps = mycon.prepareStatement(sql);
            ps.setInt(1, obj.getIdJogo());
            ps.setString(2, obj.getIdCliente());
            ps.setBoolean(3, obj.isIdStatus());
            ps.execute();
            ps.close();
            JOptionPane.showMessageDialog(null, "Registro Incluído com Sucesso!");
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao incluir emprestimo!" + err.getMessage());
        }
    }
    
    public void alterar (Emprestimo obj) {
          sql = "UPDATE EMPRESTIMOS SET idJogo = ?, idCliente = ?, status = ? WHERE idJogo = ?";
          
          try {
            ps = mycon.prepareStatement(sql);
            ps.setInt(1, obj.getIdJogo());
            ps.setString(2, obj.getIdCliente());
            ps.setBoolean(3, obj.isIdStatus());
            ps.setInt(4, obj.getIdJogo());
            ps.execute();
            ps.close();
            JOptionPane.showMessageDialog(null, "Registro Incluído com Sucesso!");
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao incluir emprestimo!" + err.getMessage());
        }
    }

    public ResultSet buscartodos() {
        sql = "SELECT * FROM EMPRESTIMOS ORDER BY IdJogo ";
        try {
            ps = mycon.prepareStatement(sql);
            return ps.executeQuery();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao Buscar emprestimo!"
                    + err.getMessage());
            return null;
        }
    }
    
    public ResultSet buscar(Emprestimo obj) {
// para buscar um registro especifico cria-se um sql com um parãmetro chave
        sql = "SELECT * FROM EMPRESTIMOS WHERE idJogo = ?";
        try { // liga o sql com a conexão atraveś do objeto ps
            ps = mycon.prepareStatement(sql);
    // configura o único parametro existente
            ps.setInt(1, obj.getIdJogo());
    // retorna o registro selecionado
            return ps.executeQuery();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao Buscar usuário!"
                    + err.getMessage());
            return null;
        }
    }
    
    public void excluir(String idJogo) {
// configura o comando sql de exclusão delete por cpf
        sql = "DELETE FROM EMPRESTIMOS WHERE idJogo = '" + idJogo + "'";
        try { // envia o comando sql para dentro da conexão através deps 
            ps = mycon.prepareStatement(sql);
// executa o comando delete dentro do mysql
            ps.execute();
            ps.close(); // fecha o objeto usado para executar o comando sql
            JOptionPane.showMessageDialog(null,"Registro Excluido com Sucesso"
                    + "!");
} catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao Excluir emprestimo!"
                    + err.getMessage());
        }
    }
    


 
  }
    
    
   

